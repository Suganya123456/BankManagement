import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  submitted = false;
  username: string = '';
  password: string = '';
  isUsernameValid: boolean = true;
  textValue: string = '';
  errorMessage: string = '';


  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  onKey(event: any, type: string) {
    if (type === 'username') {
      this.username = event.target.value;
      this.validateUsername();
    } else if (type === 'password') {
      this.password = event.target.value;
    }
  }
  validateUsername(): void {
    const pattern = RegExp(/^[\w-.]*$/);
    if (pattern.test(this.username)) {
      this.isUsernameValid = true;
    } else {
      this.isUsernameValid = false;
    }
  }



// goToHome() {
//   console.log('Hiiiii');
//   this.router.navigate(['./home']);
// }
register() {
  console.log('Hiiiii');
 // this.router.navigate(['./registration']);
  this.router.navigateByUrl('/registration');
}

}